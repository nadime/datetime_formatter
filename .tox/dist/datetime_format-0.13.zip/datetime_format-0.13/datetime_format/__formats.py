from datetime import date, datetime, time, timedelta
import functools
import re

__all__ = [
    "_DATE_DELTAS",
    "_DATE_SPLIT_CHARS",
    "_DATE_STYLES",
    "_DATE_SWITCHOVER",
    "_SUPPORTED_DATE_FORMATS",
    "_TIME_SPLIT_CHARS",
    "_TIME_STYLES",
    "_SUPPORTED_TIME_FORMATS",
]

_DATE_SPLIT_CHARS = ["-", "/"]
_TIME_SPLIT_CHARS = [":"]

# preference goes in this order as well, though it is baked into the code so
# changing the order of the below list will not affect, i.e. always prefer
# american style MM-DD over DD-MM
_DATE_STYLES = [
    "YYYY{sc}MM{sc}DD",
    "MM{sc}DD{sc}YYYY",
    "DD{sc}MM{sc}YYYY",
    "MM{sc}DD{sc}YY",
    "MM{sc}DD{sc}YY",
]

_TIME_STYLES = [
    "HH{sc}MM{sc}SS[.ZZZ]",
    "HH{sc}MM"
]

# two digit years are assumed to be 1900+YY for anything > 40, or
# 2000 + YY for anything <= 40.  Use YYYY for better accuracy ;)
_DATE_SWITCHOVER = 40

_SUPPORTED_DATE_FORMATS = [
    item.format(sc=split_char)
        for split_char in _DATE_SPLIT_CHARS
            for item in _DATE_STYLES
]
_SUPPORTED_TIME_FORMATS = [
    item.format(sc=split_char)
        for split_char in _TIME_SPLIT_CHARS
            for item in _TIME_STYLES
]

# e.g. YYYYMMDD-M1D = YYYYMMDD format, translate minus 1 day before output
_PARSE_DT_SUB_REGEX = r"(%(?P<format>[^-^{^}]+?)(?:-(?P<translation>\w+))?%)"
_PARSE_DT_REGEX = re.compile("^" + _PARSE_DT_SUB_REGEX + "$")

# e.g. M1D for minus 1 day, P10Y for plus 10 years, etc.
_PARSE_DT_TRANSLATION = r"^(?P<dir>[MmPp])(?P<num>\d+)(?P<size>[A-Za-z])$"

_dtformat = functools.partialmethod(datetime.strftime)
_dttranslate = functools.partialmethod(timedelta)

_DATE_DELTAS = [ "days", "weeks", "months", "years" ]

# case sensitive
_SUPPORTED_TRANSLATION_SIZES = {
    "Y":    "years",
    "m":    "months",
    "D":    "days",
    "W":    "weeks",
    "H":    "hours",
    "M":    "minutes",
    "S":    "seconds",
    "Z":    "microseconds",
    "B":    "business_days"
}

# not case sensitive
_SUPPORTED_TRANSLATION_DIRECTIONS = {
    "M": -1,
    "P": 1,
}
_SUPPORTED_TRANSLATION_DIRECTIONS.update(
    {k.lower(): v for k, v in _SUPPORTED_TRANSLATION_DIRECTIONS.items()}
)

# not case sensitive
_SUPPORTED_DATETIME_OUTPUT_FORMATS = {
    "DATE":         "%x",
    "TIME":         "%X",
    "YEAR":         "%Y",
    "YYYYMM":       "%Y%m",
    "MMYYYY":       "%m%Y",
    "YYMM":         "%y%m",
    "MMYY":         "%m%y",
    "YYYYMMDD":     "%Y%m%d",
    "MMDDYY":       "%m%d%y",
    "MMDDYYYY":     "%m%d%Y",
    "ISODATE":      "%Y-%m-%d",
    "MONTH":        "%m",
    "MON":          "%m",
    "MONTHABV":     "%b",
    "MONTHNAME":    "%B",
    "DAYABV":       "%a",
    "DAYNAME":      "%A",
    "DAYNUM":       "%w",
    "DAYYEAR":      "%j",
    "TZOFF":        "%z",
    "TZNAME":       "%Z",
    "WEEKNUM":      "%W",
    "DAY":          "%d",
    "DD":           "%d",
    "MM":           "%m",
    "YY":           "%y",
    "YYYY":         "%Y",
    "LOCALE_DT":    "%c",
    "HHMMSS":       "%H:%M:%S",
    "HHMMSSZZ":     "%H:%M:%S.%f",
    "AMPM":         "%p",
    "HH":           "%H",
    "HH12":         "%I",
    "HOUR":         "%H",
    "MIN":          "%M",
    "SECOND":       "%S",
    "SS":           "%S",
    "MICROSECOND":  "%f",
    "ZZ":           "%f",
}
_SUPPORTED_DATETIME_OUTPUT_FORMATS.update(
    {k.lower(): v for k, v in _SUPPORTED_DATETIME_OUTPUT_FORMATS.items()}
)
